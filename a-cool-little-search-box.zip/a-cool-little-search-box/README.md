# A cool little search box

A Pen created on CodePen.io. Original URL: [https://codepen.io/jonwelsh/pen/kymgyQ](https://codepen.io/jonwelsh/pen/kymgyQ).

A transparent search box to sit on a large image